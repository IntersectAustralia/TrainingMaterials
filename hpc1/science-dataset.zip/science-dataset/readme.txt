A collection of scientific datasets

(In reality, random data to illustrate downloading data)


